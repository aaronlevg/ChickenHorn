Replaces the Airhorn sound effect with the Rubber Chicken sound effect.

Please install "no00ob-LCSoundTool-1.2.2" first. It is the same process below, just move the .dll file into your plugins folder in BepInEx.

Drag .dll and .wav files to plugins folder in BepInEx